function obliczSrednia(tablica) {
    let suma = 0;
    for (let i = 0; i < tablica.length; i++) {
        for (let j = 0; j < tablica[i].length; j++) {
            suma += tablica[i][j];
        }
    }
    const iloscElementow = tablica.length * tablica[0].length;
    const srednia = suma / iloscElementow;
    return srednia;
}

const tablica = [];
for (let i = 0; i < 10; i++) {
    const wiersz = [];
    for (let j = 0; j < 10; j++) {
        wiersz.push(Math.floor(Math.random() * 900) + 100); // Losowa liczba trzycyfrowa
    }
    tablica.push(wiersz);
}

const outputDiv = document.getElementById('output');
outputDiv.innerHTML += "<h2>Zawartość tablicy:</h2>";
outputDiv.innerHTML += "<pre>" + tablica.map(row => row.join("\t")).join("\n") + "</pre>";
outputDiv.innerHTML += "<h2>Średnia wartość:</h2>";
outputDiv.innerHTML += "<p>" + obliczSrednia(tablica) + "</p>";
