function displayReversedText() {
  var userInput = document.getElementById("textInput").value;
  var reversedText = reverseString(userInput);
  document.getElementById("result").innerHTML = "Oryginalny tekst: " + userInput + "<br>Odwrócony tekst: " + reversedText;
}

function reverseString(str) {
  return str.split("").reverse().join("");
}
