<?php
session_start();
$conn = new mysqli("localhost", "root", "", "mydatabase");
if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}
?>
