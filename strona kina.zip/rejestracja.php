<?php
require 'config.php';

if (isset($_POST['register'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $check_sql = "SELECT id FROM users WHERE username = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $username);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        $error_message = "Błąd: Nazwa użytkownika jest już zajęta!";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $hashed_password);

        if ($stmt->execute()) {
            $_SESSION['message'] = "Rejestracja zakończona sukcesem! Możesz się teraz zalogować.";
            header("Location: logowanie.html");
            exit();
        } else {
            $error_message = "Błąd rejestracji: " . $stmt->error;
        }
        $stmt->close();
    }

    $check_stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pl">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zarejestruj się</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .table {
            width: 400px;
            margin: 190px auto;
            padding: 20px;
            background: rgba(0, 0, 0, 0.8);
            text-align: center;
            border-radius: 15px;

        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            text-align: left;
            margin-bottom: 5px;
        }

        input {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 5px;
        }
    </style>
</head>

<body>

    <header>
        <h1>Kino Belenko</h1>
    </header>
    <section class="theme">
        <label for="theme-select">Wybierz motyw:</label>
        <select id="theme-select">
            <option style="background-color: black; color: white;" value="dark">Ciemny</option>
            <option value="light">Jasny</option>
            <option style="background-color: black; color: #04ff00" value="contrast">Kontrast</option>
        </select>
    </section>
    <main>
        <section class="table" class="light-theme">
            <h2>Zarejestruj się</h2>
            <?php if (isset($error_message)) : ?>
                <p class="error"><?php echo $error_message; ?></p>
            <?php endif; ?>
            <form action="rejestracja.php" method="post">
                <label for="username">Nazwa użytkownika:</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Hasło:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit" name="register" class="cta-button">Zarejestruj się</button>
            </form>
            <a href="http://localhost/logowanie.html">
                <p>Masz już konto? Zaloguj się!</p>
            </a>
        </section>
    </main>
    <footer>
        <p>&copy; Kino samochodowe Belenko</p>
    </footer>
    <script>
        document.getElementById("theme-select").addEventListener("change", function () {
            document.body.className = this.value + "-theme";
        });
    </script>
</body>

</html>


