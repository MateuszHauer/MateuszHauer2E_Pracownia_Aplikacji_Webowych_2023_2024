function acceptCookies() {
    document.getElementById("cookiesBanner").style.display = "none";
    localStorage.setItem("cookiesAccepted", "true");
}