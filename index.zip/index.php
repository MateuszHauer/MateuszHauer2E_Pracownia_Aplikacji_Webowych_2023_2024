<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <P>
 <?php
$zmienna1 = 1;
$zmienna2 = 15.65;
$zmienna3 = "abc";
echo $zmienna1, $zmienna2, $zmienna3;
?>
</p>
    
</body>
</html>